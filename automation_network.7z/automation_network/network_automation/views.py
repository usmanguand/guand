from django.shortcuts import render, HttpResponse,get_object_or_404, redirect
from django.views.generic import TemplateView
from .models import Device, Log
import time
import paramiko
from datetime import datetime
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth import authenticate, login, logout
# from yourproject.utils import render_to_pdf #created in step 4
# from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
# from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
# from reportlab.lib.units import inch
# from reportlab.lib.pagesizes import A4, landscape
# from reportlab.lib import colors


# Create your views here.

def loginView(request):
    context =  {
        'page_title': 'LOGIN'
    }
    if request.method == "POST":
        #print(request.POST)
        username_login = request.POST['username']
        password_login = request.POST['password']

        user = authenticate(request, username=username_login, password=password_login)
        print(user)
        
        if user is not None:
            login(request, user)

            return redirect('home')
        else:
            return redirect('login')  ### terakhir sampai sini

    # print(request.user.is_authenticated)

    # template_name = None
    # if request.user.is_authenticated:
    #      template_name = 'index'
    # else:
    #      template_name = 'logout'

    return render(request, 'login3.html', context)

    #    print(username)
    #    print(password)
    # username1 = 'admin'
    # password1 = 'admin123'

    # user = authenticate(request, username=username1, password=password1)
    # print(user)

    # login(request, user)



def logoutView(request):
    context = {
        'page_title':'logout'
    }
    if request.method == "POST":
        if request.POST["logout"] == "Submit":
            logout(request)
        return redirect('login')
        print("logout")
   
    print(request.user.is_authenticated)

    template_name = None
    if request.user.is_authenticated:
         template_name = 'logout.html'
    else:
         template_name = 'login'

    return render(request, template_name, context)    




def home(request):
    
    all_device = Device.objects.all()
    cisco_device = Device.objects.filter(vendor="cisco")
    mikrotik_device = Device.objects.filter(vendor="mikrotik")
    last_event = Log.objects.all().order_by('-id')[:5]
    context = {
        'all_device'        : len(all_device),
        'cisco_device'      : len(cisco_device),
        'mikrotik_device'   : len(mikrotik_device),
        'last_event'        : last_event
    }
   
    print(request.user.is_authenticated)

    template_name = None
    if request.user.is_authenticated:
         template_name = 'home.html'
    else:
         template_name = 'login'
             
    return render(request, template_name, context)

def devices(request):
    all_device = Device.objects.all()

    context = {
        'all_device' : all_device
    }
    
    print(request.user.is_authenticated)

    template_name = None
    if request.user.is_authenticated:
         template_name = 'devices.html'
    else:
         template_name = 'login'
             
    return render(request, template_name, context)

def configure(request):
    if request.method == "POST":
        selected_device_id = request.POST.getlist('device')
        mikrotik_command = request.POST['mikrotik_command'].splitlines()
        cisco_command = request.POST['cisco_command'].splitlines()
        for x in selected_device_id :

            try:
                dev = get_object_or_404(Device, pk=x)
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh_client.connect(hostname=dev.ip_address, username=dev.username, password=dev.password)

                if dev.vendor.lower() == 'cisco':
                    conn = ssh_client.invoke_shell()
                    conn.send('conf t\n')
                    for cmd in cisco_command:
                        conn.send(cmd + '\n')
                        time.sleep(1)
                else :
                    for cmd in mikrotik_command:
                        ssh_client.exec_command(cmd)
                log = Log(target=dev.ip_address, action="Config", status="OK", time=datetime.now(), message=e)
                log.save()
            except Exception as e:
                log = Log(target=dev.ip_address, action="Config", status="Error", time=datetime.now(), message=e)
                log.save()
        return redirect('home')
    else:
        devices = Device.objects.all()
        context = {
            'device'    : devices,
            'mode'      : "Configure"
        }
        print(request.user.is_authenticated)

        template_name = None
        if request.user.is_authenticated:
            template_name = 'config.html'
        else:
            template_name = 'login'
                
        return render(request, template_name, context)
        

def backup(request):
    now = datetime.now()
    if request.method == "POST":
        selected_device_id = request.POST.getlist('device')
        # mikrotik_command = request.POST['mikrotik_command'].splitlines()
        # cisco_command = request.POST['cisco_command'].splitlines()
        filename = "%s_%.2i%.2i" % (now.year,now.month,now.day)
        filename2 = (Device.hostname)
        for x in selected_device_id :

            try:
                dev = get_object_or_404(Device, pk=x)
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh_client.connect(hostname=dev.ip_address, username=dev.username, password=dev.password)

                if dev.vendor.lower() == 'mikrotik':
                    ssh_client.exec_command('/export file={}'.format(filename))
                    # stdin,stdout,stderr = remote_conn_pre.exec_command('/log print')
                    # conn = ssh_client.invoke_shell()
                    # conn.send('conf t\n')
                    # for cmd in cisco_command:
                    #     conn.send(cmd + '\n')
                    #     time.sleep(1)
                else :
                    conn = ssh_client.invoke_shell()
                    conn.send('conf t\n')
                    # for cmd in cisco_command:
                    #     conn.send(cmd + '\n')
                    #     time.sleep(1)
                log = Log(target=dev.ip_address, action="Config", status="OK", time=datetime.now(), message="Ok")
                log.save()
            except Exception as e:
                log = Log(target=dev.ip_address, action="Config", status="Error", time=datetime.now(), message=e)
                log.save()
        return redirect('home')
    else:
        devices = Device.objects.all()
        context = {
            'device'    : devices,
            'mode'      : "Backup"
        }
        print(request.user.is_authenticated)

        template_name = None
        if request.user.is_authenticated:
            template_name = 'backup.html'
        else:
            template_name = 'login'
                
        return render(request, template_name, context)
        



def verify_config(request):
    if request.method == "POST":
        result = []
        selected_device_id = request.POST.getlist('device')
        mikrotik_command = request.POST['mikrotik_command'].splitlines()
        cisco_command = request.POST['cisco_command'].splitlines()
        for x in selected_device_id :
            
            try :
                dev = get_object_or_404(Device, pk=x)
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh_client.connect(hostname=dev.ip_address, username=dev.username, password=dev.password)
                if dev.vendor.lower() == 'mikrotik':
                    for cmd in mikrotik_command:
                        stdin,stdout,stderr = ssh_client.exec_command(cmd)
                        time.sleep(1)
                        result.append("Result on {}".format(dev.ip_address))
                        result.append(stdout.read().decode())
                else :
                    conn = ssh_client.invoke_shell()
                    conn.send('terminal length 0\n')
                    for cmd in cisco_command:
                        result.append('Result on {}'.format(dev.ip_address))
                        conn.send(cmd + "\n")
                        time.sleep(1)
                        output = conn.recv(65535)
                        result.append(output.decode())
                log = Log(target=dev.ip_address, action="Verifikasi Configurasi", status="OK", time=datetime.now(),message="Mantap")
                log.save()
            except Exception as e:
                log = Log(target=dev.ip_address, action="Verifikasi Configurasi", status="Error", time=datetime.now(), message=e)
                log.save()
        result = '\n'.join(result)
        return render(request, 'verify_result.html', {'result':result})
    else:
        devices = Device.objects.all()
        context = {
            'device'    : devices,
            'mode'      : "Verify Config"
        }
        print(request.user.is_authenticated)

        template_name = None
        if request.user.is_authenticated:
            template_name = 'config.html'
        else:
            template_name = 'login'
                
        return render(request, template_name, context)
        

def log(request):
    logs = Log.objects.all()

    context = {
        'logs' : logs
    }

    print(request.user.is_authenticated)

    template_name = None
    if request.user.is_authenticated:
        template_name = 'log.html'
    else:
        template_name = 'login'
                
    return render(request, template_name, context)
        

