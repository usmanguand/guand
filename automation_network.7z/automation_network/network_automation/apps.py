from django.apps import AppConfig


class NetworkAutomationConfig(AppConfig):
    name = 'network_automation'
