from django import forms
from django.forms import BaseFormSet
from django.utils.translation import ugettext_lazy as _
from django.forms import ModelForm, modelformset_factory, formset_factory
from .models import Connect, Ip, c_Setting as settings


class NacmForm(ModelForm):
	password = forms.CharField(widget=forms.PasswordInput,required = False)
	# conft = forms.Textarea()
	class Meta:
		model = Connect
		fields = ['username', 'password','conft']

	labels = {'conft':_('Config'),}

# class RequiredFormSet(BaseFormSet):
#     def __init__(self, *args, **kwargs):
#         super(RequiredFormSet, self).__init__(*args, **kwargs)
#         for form in self.forms:
#             form.empty_permitted = False

class IpForm(ModelForm):
	vendor = forms.ModelChoiceField(queryset=settings.objects.all().order_by('sett_name'))
	class Meta:
		model = Ip
		fields = ['ipaddr','vendor']
	labels = {'ipaddr':_('IP address'),}


IpFormset = formset_factory(IpForm,  extra=1)
# IpFormset = formset_factory(IpForm,  extra=1, formset=RequiredFormSet)

