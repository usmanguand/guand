#from django.contrib import admin
from django.urls import path
from django.views.generic.base import TemplateView
from django.conf.urls import url
from . import views

urlpatterns = [
    path('', views.loginView, name="login"),
    path('logout', views.logoutView, name="logout"),
    path('home', views.home, name="home"),
    path('devices', views.devices, name='devices'),
    path('configure', views.configure, name= "config"),
    path('verify_config', views.verify_config,name= "verify"),
    path('log', views.log, name="log"),
    path('backup', views.backup, name="backup"),
    # url(r'^device/',views.recent),
    # url(r'^device/', TemplateView.as_view(template_name='device'))
]
